<!-- Surface Field -->
<div class="form-group">
    {!! Form::label('surface', 'Surface:') !!}
    <p>{!! $court->surface !!}</p>
</div>

<!-- Floodlights Field -->
<div class="form-group">
    {!! Form::label('floodlights', 'Floodlights:') !!}
    <p>{!! $court->floodlights !!}</p>
</div>

<!-- Indoor Field -->
<div class="form-group">
    {!! Form::label('indoor', 'Indoor:') !!}
    <p>{!! $court->indoor !!}</p>
</div>

