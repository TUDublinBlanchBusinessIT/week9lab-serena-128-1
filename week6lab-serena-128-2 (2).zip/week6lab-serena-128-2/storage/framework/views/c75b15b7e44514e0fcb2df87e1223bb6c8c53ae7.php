<!-- Bookingdate Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('bookingdate', 'Bookingdate:'); ?>

    <?php echo Form::date('bookingdate', null, ['class' => 'form-control']); ?>

</div>

<!-- Starttime Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('starttime', 'Starttime:'); ?>

    <?php echo Form::text('starttime', null, ['class' => 'form-control']); ?>

</div>

<!-- Endtime Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('endtime', 'Endtime:'); ?>

    <?php echo Form::text('endtime', null, ['class' => 'form-control']); ?>

</div>

<!-- Memberid Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('memberid', 'Memberid:'); ?>

	<!-- Memberid Field -->
<div class="form-group col-sm-6">
    <select name="memberid" class="form-control">
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($member->id); ?>"><?php echo e($member); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
</div>

<!-- Courtid Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('courtid', 'Courtid:'); ?>

<div class="form-group col-sm-6">
    <select name="courtid" class="form-control">
        <?php $__currentLoopData = $courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($court->id); ?>"><?php echo e($court); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
</div>
</div>

<!-- Fee Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fee', 'Fee:'); ?>

    <?php echo Form::number('fee', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('bookings.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\laravel\tennisClub\resources\views/bookings/fields.blade.php ENDPATH**/ ?>