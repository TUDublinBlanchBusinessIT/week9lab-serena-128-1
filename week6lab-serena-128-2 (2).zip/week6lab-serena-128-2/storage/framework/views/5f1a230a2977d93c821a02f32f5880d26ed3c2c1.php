<FORM method="POST" action="/customers/update"> 
    <?php echo csrf_field(); ?> <input type="hidden" name="id" value="<?php echo e($customer->id); ?>"> 
    Enter your first name:<input type="text" name="firstname" value="<?php echo e($customer->firstname); ?>"><br> 
    Enter your surname:<input type="text" name="surname" value="<?php echo e($customer->surname); ?>"><br> <input type="submit"> 
</FORM> <?php /**PATH C:\laravel\tennisClub\resources\views/customers/edit.blade.php ENDPATH**/ ?>