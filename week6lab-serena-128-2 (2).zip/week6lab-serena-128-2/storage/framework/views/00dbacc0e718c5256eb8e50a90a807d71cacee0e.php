<ul class="nav navbar-nav pull-right">
	<?php if(Auth::guest()): ?>
		<li>
			<a href=" <?php echo e(route ('register')); ?>">Register
				<span class="glyphicon glyphicon-pencil"></span>
			</a>
		</li>
		<li>
			<a href="<?php echo e(route ('login')); ?>">Login
				<span class="glyphicon glyphicon-log-in"></span>
			</a>
		</li>
	<?php else: ?>
		<li>
			<a href="<?php echo e(route ('login')); ?>">Logout
				<span class="glyphicon glyphicon-log-out"></span>
			</a>
		</li>
	<?php endif; ?>
</ul><?php /**PATH C:\laravel\tennisClub\resources\views/layouts/navAuth.blade.php ENDPATH**/ ?>