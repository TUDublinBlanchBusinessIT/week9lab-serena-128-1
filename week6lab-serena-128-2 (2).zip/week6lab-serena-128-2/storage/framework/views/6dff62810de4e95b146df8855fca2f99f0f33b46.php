<!-- Firstname Field -->
<div class="form-group">
    <?php echo Form::label('firstname', 'Firstname:'); ?>

    <p><?php echo $member->firstname; ?></p>
</div>

<!-- Surname Field -->
<div class="form-group">
    <?php echo Form::label('surname', 'Surname:'); ?>

    <p><?php echo $member->surname; ?></p>
</div>

<!-- Membertype Field -->
<div class="form-group">
    <?php echo Form::label('membertype', 'Membertype:'); ?>

    <p><?php echo $member->membertype; ?></p>
</div>

<!-- Dateofbirth Field -->
<div class="form-group">
    <?php echo Form::label('dateofbirth', 'Dateofbirth:'); ?>

    <p><?php echo $member->dateofbirth; ?></p>
</div>

<?php /**PATH C:\laravel\tennisClub\resources\views/members/show_fields.blade.php ENDPATH**/ ?>